# Define opcodes and instruction mappings
opcodes = {
    "MOVE": "00",      # Move instruction opcode
    "BINARY": "01",    # Binary operator instruction
    "BRANCH": "10",    # Unconditional branch
    "CONDITIONAL_BRANCH": "11" # Conditional branch
}

# Define destination and source mappings
registers = {
    "ACC": "00",         # ACC register
    "LR": "01",          # Light register (LR)
    "ACC_LOW": "10",     # ACC low 4 bits
    "ACC_HIGH": "11"     # ACC high 4 bits
}

srcs = {
    "ACC": "00",         # ACC as source
    "LR": "01",          # LR as source
    "IR_LOW": "10",      # IR low 4 bits, sign extended
    "ALL_ONES": "11"     # All 1s
}

binary_ops = {
    "ADD": "000",        # Add operation
    "SUB": "001",        # Subtract operation
    "SHL": "010",        # Shift left
    "SHR": "011",        # Shift right with sign bit
    "XOR": "100",        # XOR operation
    "AND": "101",        # AND operation
    "ROL": "110",        # Rotate left
    "ROR": "111"         # Rotate right
}

# Assemble human-readable instructions into machine code
def assemble(instructions):
    machine_code = []

    for instruction in instructions:
        parts = instruction.split()

        if parts[0] == "MOVE":
            # Move instruction: MOVE src dest value
            src = srcs[parts[1]]  # Source register
            dest = registers[parts[2]]  # Destination register
            if len(parts) == 4:
                value = format(int(parts[3]), "04b")  # Value to move (4-bit)
            else:
                value = "0000"
            machine_code.append(f"{opcodes['MOVE']}{dest}{src}{value}")

        elif parts[0] in binary_ops:
            # Binary operation instruction: ADD/SUB/XOR dest src value
            op = binary_ops[parts[0]]  # Binary operation (add, sub, etc.)
            src = srcs[parts[2]]  # Source register
            dest = "0" if parts[1] == "ACC" else "1"  # Destination ACC or LR
            if len(parts) == 4:
                value = format(int(parts[3]), "02b")  # Value to use (2-bit)
            else:
                value = "00"
            machine_code.append(f"{opcodes['BINARY']}{op}{src}{dest}{value}")

        elif parts[0] == "BRANCH":
            # Unconditional branch: BRANCH addr
            addr = format(int(parts[1]), "04b")  # Branch address (4-bit)
            machine_code.append(f"{opcodes['BRANCH']}0000{addr}")

        elif parts[0] == "CONDITIONAL_BRANCH":
            # Conditional branch if zero: BRANCH_IF_ZERO src addr
            src = "0" if parts[1] == "ACC" else "1"  # Branch if ACC or LR is zero
            addr = format(int(parts[2]), "04b")  # Branch address (4-bit)
            machine_code.append(f"{opcodes['CONDITIONAL_BRANCH']}{src}000{addr}")

    return machine_code

# Example usage:
instructions = [
    "MOVE IR_LOW ACC_HIGH 1",       
    "MOVE ACC LR",            
    "SUB ACC IR_LOW 1",     
    "MOVE ACC LR",    
    "CONDITIONAL_BRANCH ACC 6",      
    "BRANCH 2",              
    "MOVE IR_LOW ACC_LOW 8",
    "MOVE ALL_ONES LR",  
    "XOR LR ALL_ONES",
    "SUB ACC IR_LOW 1", 
    "CONDITIONAL_BRANCH ACC 12",      
    "BRANCH 7",   
    "BRANCH 0",
]

machine_code = assemble(instructions)

# Output the machine code
print("data <=")
for i, code in enumerate(machine_code):
    print(f"\"{code}\" when addr = \"{i:04b}\" else -- {instructions[i]}")
print("\"1111111111\"; \nend rtl;")
